<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\WatchLater;
use App\Models\Video;

class WatchLaterController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api');
    }

    public function index()
    {
        $watchLater = watchLater::where('user_id', auth()->user()->id)
        ->get();
        return response()
        ->json($watchLater);
    }

    public function watchLater($video_id)
    {
        $video = Video::where('id', $video_id)
        ->first();
        if(!$video)
        {
            return response()
            ->json('Not Found');
        }
        $data = WatchLater::where('video_id', $video->id)
        ->where('user_id' , auth()->user()->id)
        ->first();
        if(! $data)
        {
            WatchLater::create([
                'user_id' => auth()->user()->id,
                'video_id' => $video_id
            ]);
            return response()
            ->json('Video Added To Watch Later');
        }
        $data->delete();
        return response()
        ->json('Video Removed From Watch Later');
    }
}
