<?php

namespace App\Http\Controllers\API;

use App\Models\Like;
use App\Models\Video;
use App\Models\Dislike;
use App\Models\Notification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class ActionController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api');
    }

    public function like($id)
    {
        $video = Video::where('id', $id)
            ->first();
        $like = Like::where('video_id', $id)
            ->where('user_id', Auth::user()->id)
            ->first();
        $dislike = Dislike::where('video_id', $id)
            ->where('user_id', Auth::user()->id)
            ->first();
        if ($video == null) {
            return response()
                ->json('Not Found');
        } else {
            if ($like == null && $dislike == null) {
                Like::create([
                    'user_id' => Auth::user()->id,
                    'video_id' => $id
                ]);
                Notification::create([
                    'user_id' => auth()->user()->id,
                    'notify_id' => $video->user_id,
                    'video_id' => $id,
                    'message' => auth()->user()->name . " Liked " . $video->title,
                ]);
                return response()
                    ->json('You Liked This Video');
            } elseif ($like == null && isset($dislike)) {
                Like::create([
                    'user_id' => Auth::user()->id,
                    'video_id' => $id
                ]);
                Notification::create([
                    'user_id' => auth()->user()->id,
                    'notify_id' => $video->user_id,
                    'video_id' => $id,
                    'message' => auth()->user()->name . " Liked " . $video->title,
                ]);
                $dislike->delete();
                return response()
                    ->json('You Liked This Video');
            } elseif (isset($like) && $dislike == null) {
                $like->delete();
                Notification::create([
                    'user_id' => auth()->user()->id,
                    'notify_id' => $video->user_id,
                    'video_id' => $id,
                    'message' => auth()->user()->name . " DisLiked " . $video->title,
                ]);
                return response()
                    ->json('Like Removed');
            }
        }
    }

    public function dislike($id)
    {
        $video = Video::where('id', $id)
            ->first();
        $like = Like::where('video_id', $id)
            ->where('user_id', Auth::user()->id)
            ->first();
        $dislike = Dislike::where('video_id', $id)
            ->where('user_id', Auth::user()->id)
            ->first();
        if ($video == null) {
            return response()
                ->json('Not Found');
        } else {
            if ($like == null && $dislike == null) {
                Dislike::create([
                    'user_id' => Auth::user()->id,
                    'video_id' => $id
                ]);
                Notification::create([
                    'user_id' => auth()->user()->id,
                    'notify_id' => $video->user_id,
                    'video_id' => $id,
                    'message' => auth()->user()->name . " DisLiked " . $video->title,
                ]);
                return response()
                    ->json('You Disliked This Video');
            } elseif ($dislike == null && isset($like)) {
                Dislike::create([
                    'user_id' => Auth::user()->id,
                    'video_id' => $id
                ]);
                $like->delete();
                Notification::create([
                    'user_id' => auth()->user()->id,
                    'notify_id' => $video->user_id,
                    'video_id' => $id,
                    'message' => auth()->user()->name . " DisLiked " . $video->title,
                ]);
                return response()
                    ->json('You DisLiked This Video');
            } elseif (isset($dislike) && $like == null) {
                $dislike->delete();
                Notification::create([
                    'user_id' => auth()->user()->id,
                    'notify_id' => $video->user_id,
                    'video_id' => $id,
                    'message' => auth()->user()->name . " Liked " . $video->title,
                ]);
                return response()
                    ->json('Dislike Removed');
            }
        }
    }
}
