<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Notification;

class NotificationController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api');
    }
    
    public function index()
    {
        $notifications = Notification::where('notify_id' , auth()->user()->id)
        ->get();
        return response()
        ->json($notifications);
    }
}
