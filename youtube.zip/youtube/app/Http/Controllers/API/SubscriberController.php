<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Subscriber;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Notification;

class SubscriberController extends Controller
{
    public function subscribe(Request $request)
    {
        if (Auth::user()->id != $request->user_id) {
            $validation = $request->validate([
                'user_id' => ['exists:users,id']
            ]);
            if ($validation) {
                Subscriber::create([
                    'subscriber_id' => Auth::user()->id,
                    'user_id' => $request->user_id
                ]);
                Notification::create([
                    'user_id' => auth()->user()->id,
                    'notify_id' => $request->user_id,
                    'video_id' => null,
                    'message' => auth()->user()->name . " Subscribed you",
                ]);
            }
            return response()
                ->json('Subscribed Successfully');
        }
        return response()
            ->json('Not Allowed');
    }

    public function unsubscribe($user_id)
    {
        $subscription = Subscriber::where('subscriber_id', '=', Auth::user()->id)
            ->where('user_id', '=', $user_id)
            ->first();
        if ($subscription == null) {
            return response()
                ->json('Not Found');
        }
        $subscription->delete();
        Notification::create([
            'user_id' => auth()->user()->id,
            'notify_id' => $user_id,
            'video_id' => null,
            'message' => auth()->user()->name . " Unsubscribed you",
        ]);
        return response()
            ->json('Unsubscribed Successfully');
    }
}
