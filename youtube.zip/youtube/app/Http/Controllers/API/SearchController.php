<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Video;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }
    
    public function search()
    {
        $videos = Video::where('title' , 'LIKE' , '%' . request()->input('title') . '%')
        ->where('privacy','public')
        ->get();
        return response()
        ->json($videos);
    }
}
